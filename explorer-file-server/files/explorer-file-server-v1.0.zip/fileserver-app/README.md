# Explorer File Server

A self-hosted, Windows File Explorer-inspired file manager with server-side storage and a responsive mobile UI. It uses Node.js built-ins plus the system `zip`, `unzip`, and `ffmpeg` executables. No cloud accounts, database service, analytics, or external backend integration is required.

## Features

- List, grid, compact views; search; sorting; breadcrumbs; keyboard shortcuts
- Upload with byte progress, speed, elapsed/estimated remaining time, cancel and retry
- Download individual files using browser download behavior
- Create folders; rename; delete; copy and move files/folders
- Multi-select, bulk delete, ZIP selected items, extract ZIP to a selected folder
- Image thumbnails, video thumbnail generation with FFmpeg, image/video/audio/PDF/text previews
- File properties, MIME type, byte formatting, timestamps, recursive folder size and file count
- Starred and recently opened files, dark/light theme, drag-and-drop upload
- Range requests for media playback/seeking
- Optional password protection and Docker Compose deployment

## Run directly

Requires Node.js 20+, and `zip` / `unzip`; install FFmpeg for video thumbnails.

```sh
cp .env.example .env
# Edit .env and set a strong FILESERVER_PASSWORD
set -a; . ./.env; set +a
npm start
```

Open `http://localhost:8787`. On another device on the same network, open `http://SERVER-LAN-IP:8787`.

To change the storage location, set `FILESERVER_ROOT=/path/to/storage`. `PORT` defaults to 8787. The service binds to `0.0.0.0` by default for LAN access.

## Run with Docker Compose

```sh
cp .env.example .env
# Edit .env and set a strong password
 docker compose up -d --build
```

Files persist under `./data`. The compose file requires `FILESERVER_PASSWORD` to be set. For an existing host folder whose files are not writable by the container user, set ownership once with `sudo chown -R 1000:1000 ./data` before starting (do not repeat this on every boot for a large library). Keep the service on a trusted LAN unless you have configured a secure reverse proxy/TLS and firewall rules. Do not expose this server directly to the public internet without additional hardening.

## Important limitations / honest notes

- No user accounts or per-user permissions yet. The optional password is a single shared gate.
- ZIP extraction blocks absolute paths and `..` traversal entries, but this is an early-stage self-hosted app. Do not extract untrusted archives on a sensitive server without additional archive sandboxing and security review.
- Upload retry restarts that file from the beginning; resumable/chunked uploads are not implemented yet.
- ZIP operations are synchronous server jobs. Very large archives may take time and should be run on a machine with enough free disk space.
- Folder downloads are done by creating a ZIP first; direct folder download is not supported.
- File info reports timestamps and sizes from the host filesystem. Creation timestamps may not be available on every filesystem.
- Recent items are updated when opened/streamed; starred/recent metadata is stored in `.fileserver-meta.json` in the storage root.
- Storage root hides its internal metadata and thumbnail cache from the listing.

## API smoke test

```sh
npm run check
curl http://127.0.0.1:8787/api/health
```
