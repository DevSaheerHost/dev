# Explorer File Server

A self-hosted, Windows File Explorer-inspired file manager with server-side storage and a responsive mobile UI. It uses Node.js built-ins plus the system `zip`, `unzip`, and `ffmpeg` executables. No cloud accounts, database service, analytics, or external backend integration is required.

## Features

- List, grid, compact views; search; sorting; breadcrumbs; keyboard shortcuts
- Upload with byte progress, speed, elapsed/estimated remaining time, cancel and retry
- Download individual files using browser download behavior
- Create folders; rename; delete; copy and move files/folders
- Multi-select, bulk delete, ZIP selected items, extract ZIP to a selected folder
- Image thumbnails, video thumbnail generation with FFmpeg, image/video/audio/PDF/text previews
- File properties, MIME type, byte formatting, timestamps, recursive folder size and file count
- Starred and recently opened files, dark/light theme, drag-and-drop upload
- Range requests for media playback/seeking
- Optional password protection and Docker Compose deployment

## Run directly

Requires Node.js 20+, and `zip` / `unzip`; install FFmpeg for video thumbnails.

```sh
cp .env.example .env
# Edit .env and set a strong FILESERVER_PASSWORD
set -a; . ./.env; set +a
npm start
```

Open `http://localhost:8787`. On another device on the same network, open `http://SERVER-LAN-IP:8787`.

To change the storage location, set `FILESERVER_ROOT=/path/to/storage`. `PORT` defaults to 8787. The service binds to `0.0.0.0` by default for LAN access.

## Run with Docker Compose

```sh
cp .env.example .env
# Edit .env and set a strong password
 docker compose up -d --build
```

Files persist under `./data`. The compose file requires `FILESERVER_PASSWORD` to be set. For an existing host folder whose files are not writable by the container user, set ownership once with `sudo chown -R 1000:1000 ./data` before starting (do not repeat this on every boot for a large library). Keep the service on a trusted LAN unless you have configured a secure reverse proxy/TLS and firewall rules. Do not expose this server directly to the public internet without additional hardening.

## Important limitations / honest notes

- No user accounts or per-user permissions yet. The optional password is a single shared gate.
- ZIP extraction blocks absolute paths and `..` traversal entries, but this is an early-stage self-hosted app. Do not extract untrusted archives on a sensitive server without additional archive sandboxing and security review.
- Upload retry restarts that file from the beginning; resumable/chunked uploads are not implemented yet.
- ZIP operations are synchronous server jobs. Very large archives may take time and should be run on a machine with enough free disk space.
- Folder downloads are done by creating a ZIP first; direct folder download is not supported.
- File info reports timestamps and sizes from the host filesystem. Creation timestamps may not be available on every filesystem.
- Recent items are updated when opened/streamed; starred/recent metadata is stored in `.fileserver-meta.json` in the storage root.
- Storage root hides its internal metadata and thumbnail cache from the listing.

## API smoke test

```sh
npm run check
curl http://127.0.0.1:8787/api/health
```


## This PC / multiple storage locations

The root screen now behaves like **This PC** and lists the configured storage locations. Common folders are detected when they exist: Desktop, Downloads, Documents, Pictures, Music and Videos. On Android/Termux, shared storage such as `/storage/emulated/0` and its common folders are detected if the process has storage permission. On Windows, available drive letters are detected, including removable drives mounted with a drive letter.

### Linux / Docker USB and built-in disks

A container cannot see host disks unless they are explicitly bind-mounted. Add a volume in `docker-compose.yml`, for example:

```yaml
volumes:
  - ./data:/data
  - /mnt/usb-drive:/host/usb-drive
  - /home/your-user/Downloads:/host/Downloads
```

Then set `FILESERVER_MOUNTS` in `.env` to JSON using container paths:

```env
FILESERVER_MOUNTS=[{"id":"USB Drive","label":"USB Drive","path":"/host/usb-drive","kind":"volume","icon":"💽"},{"id":"User Downloads","label":"Downloads","path":"/host/Downloads","kind":"folder","icon":"⬇️"}]
```

Restart with `docker compose up -d --build`. The service only exposes explicitly configured locations and conventional folders it can access. Never mount `/` or the entire host filesystem into an internet-exposed file server. Use a strong password and keep access restricted to trusted devices.

ZIP creation/extraction and multi-file ZIP downloads operate within one storage volume at a time. Cross-volume copy/move is supported when filesystem permissions allow it.

### Android / Termux

Run `termux-setup-storage` once and approve Android's storage permission. Shared internal storage is commonly available at `/storage/emulated/0` (or through Termux's `~/storage/shared` link). If the Android path is not visible to the server process, grant storage access first; the app deliberately does not bypass OS permissions. Start the server after granting access, and the `Phone Storage`, `Download`, `Documents`, `Pictures`, `Music`, and `Movies` locations will appear when their paths exist.
